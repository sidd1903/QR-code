package com.example.myqr;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.zxing.BarcodeFormat;
import com.journeyapps.barcodescanner.BarcodeEncoder;

public class Main3Activity extends AppCompatActivity {

    Button generateBtn;
    ImageView imageView;
    EditText field;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        getSupportActionBar().setTitle("Generate QR code");
        generateBtn=findViewById(R.id.generateBtn);
        imageView=findViewById(R.id.img);
        field=findViewById(R.id.field);

        generateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                generateCode();
            }
        });
    }

    private void generateCode() {

        String content=field.getText().toString().trim();
        BarcodeEncoder encoder=new BarcodeEncoder();
        try {

            Bitmap bitmap=encoder.encodeBitmap(content, BarcodeFormat.QR_CODE,400,400);
            imageView.setImageBitmap(bitmap);
            imageView.setVisibility(View.VISIBLE);

        }catch(Exception e) {
            Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();
        }
    }
}
